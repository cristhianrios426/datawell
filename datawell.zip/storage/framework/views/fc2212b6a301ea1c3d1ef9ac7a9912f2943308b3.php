<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="col-xs-12">
			<ol class="breadcrumb">
			  <li><a href="<?php echo e(url('/')); ?>">Inicio</a></li>			  
			  <li class="active">Preguntas Frecuentes</li>
			</ol>
		</div>
	</div>
	<div class="row">
		<div class="col-xs-12">
			<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="panel-group">
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingOne">
							<h4 class="panel-title">
							<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#faq<?php echo e($model->getKey()); ?>" aria-expanded="true" aria-controls="faq<?php echo e($model->getKey()); ?>">
								<?php echo e($key +1); ?>. <?php echo e($model->question); ?>

							</a>
							</h4>
						</div>
						<div id="faq<?php echo e($model->getKey()); ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
							<div class="panel-body">
								<?php echo $model->answer; ?>

							</div>
						</div>
					</div>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>