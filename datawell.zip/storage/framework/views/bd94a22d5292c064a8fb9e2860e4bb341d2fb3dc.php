<div class="list-group-item" >
	<a  href="#children-<?php echo e($model->getKey()); ?>" data-toggle="collapse">
		<i class="glyphicon glyphicon-chevron-right"></i><?php echo e($model->name); ?>	
	</a>
	<div class="btn-group">
		<button class="btn btn-xs btn-primary">Acciones</button>
		<button data-toggle="dropdown" class="btn btn-xs btn-primary dropdown-toggle"><span class="caret"></span></button>
		<ul class="dropdown-menu">
			<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $model)): ?> <li><a href="#" data-toggle="modal" data-target="#modal-model" data-edit="<?php echo e($model->getKey()); ?>">Editar</a></li> <?php endif; ?>
			<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $model)): ?> <li><a href="#" data-toggle="modal" data-target="#modal-model" data-remove="<?php echo e($model->getKey()); ?>">Eliminar</a></li> <?php endif; ?>

			<li><a href="#" data-create data-toggle="modal" data-parent="<?php echo e($model->getKey()); ?>" data-target="#modal-model">Crear hijo</a></li>
		</ul>
	</div>	
</div>
<?php if($model->treeChildren->count() > 0): ?>
	<div class="list-group collapse" id="children-<?php echo e($model->getKey()); ?>">
		<?php $__currentLoopData = $model->treeChildren; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php echo $__env->make('locations.list-item', ['model'=>$child], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
<?php else: ?>	
	<div class="list-group collapse" id="children-<?php echo e($model->getKey()); ?>">
		<a href="#" class="list-group-item" data-toggle="collapse">
			No hay registros
		</a>
	</div>
<?php endif; ?>										
