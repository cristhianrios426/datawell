<?php 
namespace App\ORM;
trait ApproveTrait{

	public function revisions(){
        return $this->morphMany('App\ORM\Revision', 'revisable');
    }
    
    public function approveable()
    {
        if($this->approved != 1) {
            return ($this->state == static::STATE_APPROVING  || $this->state == static::STATE_REVIEWING || $this->draft == 1 );
        }else{
            return true;
        }
        
    }

    public function blocked(){
    	return $this->approveable() && $this->state == static::STATE_REVIEWING;
    }

    public function reviewable()
    {
        return $this->state == static::STATE_APPROVING  || $this->state == static::STATE_REVIEWING ;
    }

    public function scopeApproveable($q)
    {  
       $q
        ->where('approved',0)
        ->orWhereHas('attachments', function($inneq){
            $table = $inneq->getModel()->getTable();
            $inneq->where($table.'.approved', 0);
        });
        return $q;
    }

    public function isAssignedTo($user){
        return ($this->assignedTo && 
                $this->assignedTo->getKey() == $user->getKey());
    }

    public function approveIfNeeded($user){       
        
           
        $this->draft = 0;
        $this->approved = 1;
        $this->state = 0;
        if( !$this->approvedBy){               
            $this->approved_by = $user->getKey();
            $this->approved_at = date('Y-m-d');
        }
        if( $this->assignedTo){               
            $this->assigned_to = NULL;
        }
        if( $this->sentBy){               
            $this->sent_by = NULL;
        }
        $this->save();
        
        return $this;
    }

    public function assignIfNeeded($user){        
        $this->draft = 0;
        $this->approved = 1;
        if($this->approved_by == NULL || $this->approved_by < 1){
            $this->approved_by = $user->getKey();
        }
        $this->save();
        return $this;
    }
    public function sendApprove($user){
        $this->state = static::STATE_REVIEWING;
        $this->draft = 0;    
        $this->sent_by = $user->getKey();       
        $this->save();      
        
    }

    public function assignedTo(){
        return $this->belongsTo(  User::class, 'assigned_to')->withTrashed();
    }

    public function sentBy(){
        return $this->belongsTo(  User::class, 'assigned_to')->withTrashed();
    }

    public function approvedBy(){
            return $this->belongsTo(  User::class, 'approved_by')->withTrashed();
    }

    public function textState(){
        if ($this->state == \App\ORM\Well::STATE_APPROVING || $this->state == \App\ORM\Well::STATE_REVIEWING){
            $text = "Elementos pendiente por aprobar";
        }elseif($this->approved != 1){
            $text = "No aprobado";
        }else{
            $text = "Aprobado";
        } 
        return $text;
    }

    public function scopeApproving($q, $user){
        $table = $q->getModel()->getTable();
        $q->where($table.'.state', static::STATE_APPROVING);             
    }

    public function scopeReviewing($q, $user){
        $table = $q->getModel()->getTable();
        $q->where(function($q2) use ($table, $user){
            $q2->where($user.'.sent_by', $user->getKey())->where($table.'.state', static::STATE_REVIEWING);
        });
    }
}