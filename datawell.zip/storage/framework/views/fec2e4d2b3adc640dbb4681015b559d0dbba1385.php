<div class="container">
    <div class="row">
        <div class="col-xs-12">
            <?php if( $model->exists ): ?>
              <h4 class="modal-title">Nuevo <?php echo e($entityLabel); ?></h4>  
            <?php else: ?>
              <h4 class="modal-title">Editando <?php echo e($entityLabel); ?> <?php echo e($model->name); ?></h4>
            <?php endif; ?>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12">
            <div class="form-group">
                <label >Nombre</label>
                <input type="text" name="name" class="form-control" value="<?php echo e($model->name); ?>" placeholder="Email">
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12 col-sm-6">
            <div class="form-group">
                <label >Coordenada en x</label>
                <input type="text" name="x" class="form-control" value="<?php echo e($model->x); ?>" placeholder="Email">
            </div>
        </div>
        <div class="col-xs-12 col-sm-6">
            <div class="form-group">
                <label >Coordenada en y</label>
                <input type="text" name="y" class="form-control" value="<?php echo e($model->y); ?>" placeholder="Email">
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12 col-sm-6">
            <div class="form-group">
                <label >Coordenada en z</label>
                <input type="text" name="z" class="form-control" value="<?php echo e($model->z); ?>" placeholder="Email">
            </div>
        </div>
        <div class="col-xs-12 col-sm-6">
            <div class="form-group">
                <label >Sistema de coordenadas</label>
                
            </div>
        </div>
    </div>
</div>
