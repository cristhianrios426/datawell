<?php $__env->startSection('head'); ?>
  <meta name="entity" content="<?php echo e($entityName); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <form form-save id="save-well" action="<?php echo e(( !$model->exists  ? route('well.store') : route('well.update',['id'=>$model->getKey()]))); ?>" method="<?php echo e(( !$model->exists  ? 'POST' : 'PUT' )); ?>">
         <div class="row">
            <div class="col-xs-12">
                <?php echo $__env->make('wells.state-message', ['model'=>$model], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <?php if( !$model->exists ): ?>
                            <h4 class="modal-title">Nuevo <?php echo e($entityLabel); ?></h4>
                        <?php else: ?>
                            <h4 class="modal-title">Editando <?php echo e($entityLabel); ?> <?php echo e($model->name); ?></h4>
                        <?php endif; ?>
                    </div>
                    <div class="panel-body">
                        <div class="fluid-container">
                            <div class="row">
                                <div class="col-xs-12 ">                                   
                                    <?php if($model->approved == 1 && !$user->can('updateapproved', $model)): ?>
                                        <?php echo $__env->make('wells.inner-show', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                    <?php else: ?>
                                        <?php echo $__env->make('wells.inner-create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                    <?php endif; ?>                                    
                                </div>

                                <div class="col-xs-12">
                                    <div class="row">
                                        <div class="col-xs-12">
                                            <h4>Archivos adjuntos</h4>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xs-12">
                                            <div id="list-files">
                                                <div class="row">
                                                    <?php $__currentLoopData = $model->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="col-xs-12 col-sm-6">
                                                            <div class="well " data-old-attachment >
                                                                <div>
                                                                    <span class="label label-<?php echo e($attachment->approved ? 'success' : 'warning'); ?>"><?php echo e($attachment->approved ? 'Aprobado' : 'No aprobado'); ?></span>
                                                                </div>
                                                                <a href="<?php echo e($model->routeToAttachment($attachment->id)); ?>" data-url target="_blank">
                                                                    <div data-name=""><?php echo e($attachment->name); ?></div>
                                                                </a>
                                                                <input type="hidden" data-servername name="old_attachments[<?php echo e($key); ?>][id]" value="<?php echo e($attachment->getKey()); ?>">
                                                                <input data-removed type="hidden" data-servername name="old_attachments[<?php echo e($key); ?>][deleted]" value="0">
                                                                <?php if( $user->can('fulledit', $model) || ($attachment->approved != 1 && $user->can('sendapprove', $model))): ?>
                                                                    <button data-remove class="btn btn-danger btn-xs">eliminar</button>
                                                                <?php else: ?>    
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>                                            
                                        </div>
                                        <div class="col-xs-12">
                                            <div class="btn btn-success relative" data-uploader="" >
                                                <span><i class="fa fa-cloud-upload" aria-hidden="true"></i> &nbsp;Adjuntar archivo</span>
                                                <input type="file" name="file" class="hidden-action">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-12">
                                   <small>Los campos marcado son <strong class="require-mark">*</strong> son obligatorios</small>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-12">
                                    <div alert=""></div>
                                </div>
                            </div>
                        </div>
                    </div>  
                    <div class="panel-footer text-right">                        
                        <?php if(!$model->exists): ?>                            
                            <?php if( $user->can('createdraft', \App\ORM\Well::class ) ): ?>
                                <button type="submit"  name="action" value="createdraft"  class="btn btn-primary">
                                    Guardar Borrador
                                </button>  
                            <?php endif; ?>                             
                            <?php if( $user->can('createapproved', \App\ORM\Well::class ) ): ?>
                                <button type="submit"  name="action" value="createapproved"  class="btn btn-primary">
                                    Guardar y Aprobar
                                </button>  
                            <?php endif; ?>                      
                            <?php if( $user->can('createsendapprove', \App\ORM\Well::class ) ): ?>
                                <button type="button" assigned-modal class="btn btn-primary">
                                    Enviar a aprobaci&oacute;n
                                </button>  
                            <?php endif; ?>  
                        <?php else: ?> 
                            <?php if( $user->can('draft', $model ) ): ?>
                                <button type="submit" name="action" value="draft"  class="btn btn-primary">
                                    Guardar Borrador
                                </button>
                            <?php endif; ?>                             
                            <?php if( $user->can('approve', $model ) == true): ?>                                
                                <button type="submit" name="action" value="approve"  class="btn btn-primary">
                                    Guardar y Aprobar
                                </button>
                            <?php endif; ?> 
                            <?php if( $user->can('review', $model ) == true): ?>
                                <button type="button" send-revision data-toggle="modal" data-target="#send-revision" class="btn btn-warning">
                                    Enviar revisi&oacute;n
                                </button>
                            <?php endif; ?> 
                            <?php if( $user->can('sendapprove', $model ) ): ?>
                                <?php if(!$model->assignedTo): ?>
                                    <button type="button" assigned-modal class="btn btn-primary">
                                        Enviar a aprobaci&oacute;n
                                    </button> 
                                <?php else: ?>    
                                    <button type="submit" name="action" value="sendapprove" class="btn btn-primary">
                                        Enviar a aprobaci&oacute;n
                                    </button>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if($model->exists && $model->revisions &&  $model->revisions->count() > 0): ?>
                                <button type="button" class="btn btn-info" data-toggle="modal" data-target="#revisions-modal">
                                    Ver revisiones
                                </button>
                            <?php endif; ?>
                        <?php endif; ?>
                        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-warning">
                            Cancelar
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <?php if( ( !$model->exists && $user->can('createsendapprove', $model) ) ||   ( !$model->assignedTo && $model->exists && $user->can('sendapprove', $model) ) ): ?> 
            <div class="modal fade" id="select-assigned" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title">Enviar a aprobación</h4>
                        </div>
                        <div class="modal-body">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-xs-12">
                                        <div class="alert alert-info">
                                           Envia a un supervisor
                                        </div>
                                    </div>
                                </div>
                                 <div class="row">
                                    <div class="col-xs-12">
                                        <div class="form-group">
                                            <?php if($model->approved == 1 && !$user->can('updateapproved', $model)): ?>
                                                <label >Supervisor  <strong class="require-mark">*</strong></label>
                                                <select selectpicker data-live-search="true" name="assigned_to" class="required form-control">
                                                    <?php $__currentLoopData = \App\ORM\User::vacum()->isSupervisor()->inLocation($model->location)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($element->getKey()); ?>"><?php echo e($element->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            <?php else: ?>
                                                <label >Supervisor  <strong class="require-mark">*</strong></label>
                                                <select location-dep-ref location-list="supervisor" selectpicker data-live-search="true" name="assigned_to" class="required form-control">
                                                    
                                                </select>
                                            <?php endif; ?>    
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
                            <button type="sumit" name="action" value="sendapprove" class="btn btn-primary">Enviar</button>
                        </div>
                    </div><!-- /.modal-content -->
                </div><!-- /.modal-dialog -->
            </div><!-- /.modal -->
        <?php endif; ?>
    </form>
</div>
<?php if($model->exists && $model->revisions && $model->revisions->count() > 0 ): ?>
    <div class="modal fade" id="revisions-modal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Revisiones</h4>
                </div>
                <div class="modal-body">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-xs-12">
                                <?php $__currentLoopData = $model->revisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="alert alert-info">
                                       <strong><?php echo e($revision->created_at); ?> - <?php echo e($revision->createdBy->name); ?>: </strong><br>
                                        <?php echo nl2br(e($revision->content)); ?>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
                   
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
<?php endif; ?>


<?php if( $model->exists && $user->can('review', $model ) ): ?>
<div class="modal fade" id="send-revision" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <form form-revision method="post" action="<?php echo e(route('well-revision',['id'=>$model->getKey()])); ?>">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Enviar revisi&oacute;n</h4>
                </div>
                <div class="modal-body">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="alert alert-info">
                                    Haz una descripci&oacute;n de los motivos de la revisi&oacute;n
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="form-group">
                                    <label >Contenido de revisi&oacute;n <strong class="require-mark">*</strong></label>
                                    <textarea name="content" class="required form-control"></textarea >
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12">
                                <div alert></div>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
                    <button type="sumit"  class="btn btn-primary">Enviar</button>
                </div>
            </div><!-- /.modal-content -->
        </form>
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<?php endif; ?>

<div style="display: none" id="template-file">
    <div class="col-xs-12 col-sm-6">
        <div class="well">
            <a href="#" data-url target="_blank">
                <div data-name=""></div>
            </a>
            <div data-progress=""></div>
            <input type="hidden" data-servername name="attachments[{id}][file]">
            <input type="hidden" data-clientname name="attachments[{id}][name]">
            <button data-remove="" class="btn btn-danger btn-xs">eliminar</button>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <script src="<?php echo e(asset('vendors/fileuploader/compiled.js')); ?>"></script>
    <script src="<?php echo e(asset('js/scripts/jquery.datawelluploader.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('vendors/bootstrap-select/dist/css/bootstrap-select.min.css')); ?>">
    <script src="<?php echo e(asset('vendors/bootstrap-select/dist/js/bootstrap-select.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/bootstrap-select/dist/js/i18n/defaults-'.\Config::get('app.locale').'.js')); ?>"></script>

    <script src="<?php echo e(asset('js/scripts/entity.js')); ?>"></script>  
    <script src="<?php echo e(asset('js/scripts/jquery.sendajax.js?t='.time())); ?>"></script>  
    <script src="<?php echo e(asset('js/scripts/well-controller.js?t='.time())); ?>"></script>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>