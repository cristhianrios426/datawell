<?php 	
namespace App\Repository\Exception;
class SaveException extends \Exception
{
	
}