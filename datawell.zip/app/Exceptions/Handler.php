<?php

namespace App\Exceptions;

use Exception;
use Illuminate\Session\TokenMismatchException;
use App\Util\Exception\AuthorizeException;
use Illuminate\Auth\AuthenticationException;
use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;

class Handler extends ExceptionHandler
{
    /**
     * A list of the exception types that should not be reported.
     *
     * @var array
     */
    protected $dontReport = [
        \Illuminate\Auth\AuthenticationException::class,
        \Illuminate\Auth\Access\AuthorizationException::class,
        \Symfony\Component\HttpKernel\Exception\HttpException::class,
        \Illuminate\Database\Eloquent\ModelNotFoundException::class,
        \Illuminate\Session\TokenMismatchException::class,
        \App\Repository\Exception\ValidatorException::class,
    ];

    /**
     * Report or log an exception.
     *
     * This is a great spot to send exceptions to Sentry, Bugsnag, etc.
     *
     * @param  \Exception  $exception
     * @return void
     */
    public function report(Exception $exception)
    {
        parent::report($exception);
    }

    /**
     * Render an exception into an HTTP response.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Exception  $exception
     * @return \Illuminate\Http\Response
     */
    public function render($request, Exception $exception)
    {
        if ($exception instanceof TokenMismatchException ) {            
            return $this->responseException($request,$exception, 550);
        }else if($exception instanceof AuthorizeException){
            return $this->responseAuthorize($request,$exception, 500);
        }
        return parent::render($request, $exception);
        
    }

    /**
     * Convert an authentication exception into an unauthenticated response.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Illuminate\Auth\AuthenticationException  $exception
     * @return \Illuminate\Http\Response
     */
    protected function unauthenticated($request, AuthenticationException $exception)
    {
        if ($request->expectsJson()) {
            return response()->json(['error' => 'Unauthenticated.'], 401);
        }

        return redirect()->guest(route('login'));
    }

    public function responseException($request, $e, $status = 500){
        if ( $request->isXmlHttpRequest() || $request->wantsJson()) {
            return response()->json( [
                'error' => [
                    'exception' =>$e->getMessage(),                    
                ]
            ], $status );
        }else{
            $r =  response()->view('error.standard', ['exception'=>$e], $status);
            $r->setStatusCode($status);
            return $r;
        }
    } 

    public function responseAuthorize($request, $e ){
        $status = 422;
        if (  $request->wantsJson()) {
            $messages = count($e->getCantReasons()) > 0 ? $e->getCantReasons() : [$e->getMessage()];
            return response()->json( ['messages'=>['messages'=>$messages, 'type'=>'danger']] , $status);
        }elseif( $request->isXmlHttpRequest() && !$request->wantsJson() ){
            $r = response()->view('error.simple', ['exception'=>$e]);
            $r->setStatusCode($status);
            return $r;
        }else{
            $r = response()->view('error.standard', ['exception'=>$e]);
            $r->setStatusCode($status);
            return $r;
        }
    }
}
