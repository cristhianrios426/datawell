<?php $__env->startSection('head'); ?>
	<meta name="entity" content="<?php echo e($entityName); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="col-xs-12">
			<form action="">
				<div class="panel panel-default">
					<div class="panel-heading">
						<div class="continer-fluid">
							<div class="row">
								<div class="col-xs-12">
									<div class="pull-left">
										<h4><?php echo e(ucfirst($entitiesLabel)); ?></h4>
									</div>
									<div class="pull-right">
										<a   href="<?php echo e(route($entityName.'.create')); ?>" class="btn btn-success">
											<i class="fa fa-plus"  aria-hidden="true"></i> Crear  <?php echo e($entityLabel); ?>

										</a>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="panel-body">
						<div class="fluid-container">
							<div class="row">
								<div class="col-xs-12">
									<div class="fluid-container">
										<div class="row">
											<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
												<div class="form-group">
													<label for="">Nombre</label>
										       		<input type="text" name="name" class="form-control" value="">
										      	</div>
											</div>
											<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
												<div class="form-group">
													<label for="">Tipo de servicio</label>
										       		<select name="id_service_type[]" multiple class="selectpicker form-control">
										       			<?php $__currentLoopData = $serviceTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										       				<option  <?php echo e(( isset($query['id_service_type']) && in_array($m->getKey(), $query['id_service_type']) ? 'selected' : '' )); ?> value="<?php echo e($m->getKey()); ?>"><?php echo e($m->name); ?></option>
										       			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										       		</select>
										      	</div>
											</div>
											<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
												<div class="form-group">
													<label for="">Pozo</label>
										       		<select name="id_well[]" multiple class="selectpicker form-control">
										       			<?php $__currentLoopData = $wells; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										       				<option  <?php echo e(( isset($query['id_well']) && in_array($m->getKey(), $query['id_well']) ? 'selected' : '' )); ?> value="<?php echo e($m->getKey()); ?>"><?php echo e($m->name); ?></option>
										       			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										       		</select>
										      	</div>
											</div>																							
										</div>
									</div>
								</div>
								<div class="col-xs-12">
									
								</div>
							</div>
						</div>
					</div>
					<div class="panel-footer text-right">
						<button class="btn btn-primary">
							Buscar
						</button>
						<a href="<?php echo e(route($entityName.'.index')); ?>" class="btn btn-warning">
							Limpiar
						</a>
					</div>
				</div>
			</form>
		</div>
	</div>
	<div class="row">
		<?php if($models->count() > 0): ?>
					
			<?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-xs-12 col-md-6">
					<div class="panel panel-info">
						<div class="panel-heading"><h4><?php echo e($model->name); ?></h4></div>
						<div class="panel-body">
							<ul class="list-group">
							  <li class="list-group-item"><strong>Pozo:</strong> <?php echo e($model->well ? $model->well->name : ''); ?> </li>
							  <li class="list-group-item"><strong>Tipo de servicio:</strong> <?php echo e($model->type ? $model->type->name : ''); ?> </li>
							  <li class="list-group-item"><strong>Tipo de sección:</strong> <?php echo e($model->section ? $model->section->name : ''); ?> </li>
							  <li class="list-group-item"><strong>Descripci&oacute;n:</strong> <?php echo e($model->description); ?> </li>
							</ul>
						</div>
						<div class="panel-footer text-right">
							
							<div class="btn-group">
							  <button class="btn btn-primary">Acciones</button>
							  <button data-toggle="dropdown" class="btn btn-primary dropdown-toggle"><span class="caret"></span></button>
							  <ul class="dropdown-menu">
								<li><a href="<?php echo e(route($entityName.'.show', ['id'=>$model->id])); ?>"  >Ver detalles </a></li>
							  </ul>
							</div>
						</div>
					</div>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<div class="col-xs-12">
				<div class="text-center">
					<div class="inline-block"><?php echo e($models->render()); ?></div> 	
				</div>	
			</div>
				
		<?php else: ?>
			<div class="alert alert-primary">
				<h4> No se han encontrado resultados </h4>
			</div>
		<?php endif; ?>
					
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
	<link rel="stylesheet" href="<?php echo e(asset('vendors/bootstrap-select/dist/css/bootstrap-select.min.css')); ?>">
	<script src="<?php echo e(asset('vendors/bootstrap-select/dist/js/bootstrap-select.min.js')); ?>"></script>
	<script src="<?php echo e(asset('vendors/bootstrap-select/dist/js/i18n/defaults-es_ES.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/scripts/index-well-controller.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>