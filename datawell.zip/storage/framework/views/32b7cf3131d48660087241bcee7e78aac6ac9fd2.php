<?php $__env->startSection('head'); ?>
  <meta name="entity" content="<?php echo e($entityName); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <form action="<?php echo e(( !$model->exists  ? route($entityName.'.store') : route($entityName.'.update',['id'=>$model->getKey()]))); ?>" method="<?php echo e(( !$model->exists  ? 'POST' : 'PUT' )); ?>">
        <div class="row">
            <div class="col-xs-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <?php if( !$model->exists ): ?>
                            <h4 class="modal-title">Nuevo <?php echo e($entityLabel); ?></h4>
                        <?php else: ?>
                            <h4 class="modal-title">Editando <?php echo e($entityLabel); ?> <?php echo e($model->name); ?></h4>
                        <?php endif; ?>
                    </div>
                    <div class="panel-body">
                        <div class="fluid-container">
                            <div class="row">
                                <div class="col-xs-12 col-sm-8">
                                    <div class="row">
                                        <div class="col-xs-12">
                                            <div class="form-group">
                                                <label >Nombre  <strong class="require-mark">*</strong></label>
                                                <input type="text" name="name" class="require form-control required" value="<?php echo e($model->name); ?>" >
                                            </div>
                                        </div>
                                    </div>                                    
                                    <div class="row">
                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label >Pozo <strong class="require-mark">*</strong> </label>
                                                <select name="id_well"  data-live-search="true" class="selectpicker require form-control required">
                                                    <option value="">Selecciona</option>
                                                    <?php $__currentLoopData = $wells; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $well): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                      <?php if($model->exists): ?>
                                                        <option <?php echo e(($model->id_well == $well->getKey() ? 'selected' : '' )); ?> value="<?php echo e($well->getKey()); ?>"><?php echo e($well->name); ?></option>
                                                      <?php else: ?>
                                                        <option <?php echo e(($prewell == $well->getKey() ? 'selected' : '' )); ?> value="<?php echo e($well->getKey()); ?>"><?php echo e($well->name); ?></option>
                                                      <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label >Tipo de servicio <strong class="require-mark">*</strong></label>
                                                <select name="id_service_type"  class="selectpicker require form-control required">
                                                    <option value="">Selecciona</option>
                                                    <?php $__currentLoopData = $serviceTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serviceType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                      <option <?php echo e(($model->id_service_type == $serviceType->getKey() ? 'selected' : '' )); ?> value="<?php echo e($serviceType->getKey()); ?>"><?php echo e($serviceType->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label >Tipo de secci&oacute;n <strong class="require-mark">*</strong> </label>
                                                <select name="id_section"  data-live-search="true" class="selectpicker require form-control required">
                                                    <option value="">Selecciona</option>
                                                    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                      <option <?php echo e(($model->id_section == $section->getKey() ? 'selected' : '' )); ?> value="<?php echo e($section->getKey()); ?>"><?php echo e($section->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label >Fecha de terminaci&oacute;n <strong class="require-mark">*</strong> </label>
                                                <input type="text" name="ended_at" class="form-control required date"  value="<?php echo e($model->ended_at); ?>" >
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xs-12">
                                             <div class="form-group">
                                                <label >Descripci&oacute;n</label>
                                                <textarea name="description" class="form-control" id="" ><?php echo e($model->description); ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xs-12 col-sm-4">
                                    <div class="row">
                                        <div class="col-xs-12">
                                            <h4>Archivos adjuntos</h4>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xs-12">
                                            <div id="list-files">
                                                <?php if($model->exists): ?>
                                                  <?php $__currentLoopData = $model->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                       <div class="well " data-old-attachment >
                                                          <a href="<?php echo e($model->routeToAttachment($attachment->id)); ?>" data-url target="_blank">
                                                              <div data-name=""><?php echo e($attachment->name); ?></div>
                                                          </a>
                                                          <input type="hidden" data-servername name="old_attachments[<?php echo e($key); ?>][id]" value="<?php echo e($attachment->getKey()); ?>">
                                                          <input data-removed type="hidden" data-servername name="old_attachments[<?php echo e($key); ?>][deleted]" value="0">
                                                          <button data-remove class="btn btn-danger btn-xs">eliminar</button>
                                                      </div>
                                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </div>
                                            <div class="btn btn-success relative" data-uploader="" >
                                                <span><i class="fa fa-cloud-upload" aria-hidden="true"></i> &nbsp;Adjuntar archivo</span>
                                                <input type="file" name="file" class="hidden-action">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-12">
                                   <small>Los campos marcado son <strong class="require-mark">*</strong> son obligatorios</small>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-12">
                                    <div alert=""></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="panel-footer text-right">
                        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-warning">
                            Cancelar
                        </a>
                        <button type="submit" class="btn btn-primary">
                            Guardar
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
<div style="display: none" id="template-file">
    <div class="well">
        <a href="#" data-url target="_blank">
            <div data-name=""></div>
        </a>
        <div data-progress=""></div>
        <input type="hidden" data-servername name="attachments[{id}][file]">
        <input type="hidden" data-clientname name="attachments[{id}][name]">
        <button data-remove="" class="btn btn-danger btn-xs">eliminar</button>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('vendors/bootstrap-select/dist/css/bootstrap-select.min.css')); ?>">
    <script src="<?php echo e(asset('vendors/bootstrap-select/dist/js/bootstrap-select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/fileuploader/compiled.js')); ?>"></script>
    <script src="<?php echo e(asset('js/scripts/jquery.datawelluploader.js')); ?>"></script>
    <script src="<?php echo e(asset('js/scripts/entity.js')); ?>"></script>  
    <script src="<?php echo e(asset('js/scripts/jquery.sendajax.js?t='.time())); ?>"></script>  
    <script src="<?php echo e(asset('js/scripts/service-controller.js?t='.time())); ?>"></script>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>