<?php $__currentLoopData = $listModels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currentModel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<option <?php echo e(($selected == $currentModel->getKey() ? 'selected="selected" ' : '' )); ?> value="<?php echo e($currentModel->getKey()); ?>"><?php echo e($level.$currentModel->name); ?></option>
	<?php if($currentModel->treeChildren->count() > 0): ?>
		<?php echo $__env->make('util.nested-tree-options', [ 'listModels'=>$currentModel->treeChildren, 'level'=>$level.$currentModel->name.', ', 'selected'=>$selected], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>	
	<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>