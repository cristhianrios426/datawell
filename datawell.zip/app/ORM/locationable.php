<?php 
namespace App\ORM;
interface locationable{
	
}