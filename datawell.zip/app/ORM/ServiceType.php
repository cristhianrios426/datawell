<?php
namespace App\ORM;
class ServiceType extends BaseModel
{
	use \Illuminate\Database\Eloquent\SoftDeletes;
	
    protected $fillable = [];
    protected $table = 'service_types';
    protected $dates = ['deleted_at','created_at', 'updated_at'];
}
