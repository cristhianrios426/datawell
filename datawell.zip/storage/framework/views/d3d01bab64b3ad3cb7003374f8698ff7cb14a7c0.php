<div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
    <h4 class="modal-title">
    <?php if($model->exists): ?>
    Editando <?php echo e($entityLabel); ?> <?php echo e($model->name); ?>

    <?php else: ?>
    Creando <?php echo e($entityLabel); ?>

    <?php endif; ?>
    </h4>
</div>
<form action="" form-send>
    <div class="modal-body">
        <fieldset>
            <legend class="">Datos principales</legend>                    
            <div class="row">
                <div class="col-xs-12">
                    <div class="form-group">
                        <label >Nombre Completo</label>
                        <input type="text" name="name" class="required form-control" value="<?php echo e($model->name); ?>" >
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 col-sm-6">
                    <div class="form-group">
                        <label >Email</label>
                        <input type="text" name="email" class="required email form-control" value="<?php echo e($model->email); ?>" >
                    </div>
                </div>
                <div class="col-xs-12  col-sm-6">
                    <div class="form-group">
                        <label >Estado</label>
                        <select name="state" class="required form-control" >
                            <option value="">Selecciona</option>
                            <option <?php echo e(( $model->state  == \App\ORM\User::ACTIVE ? 'selected' : '' )); ?> value="<?php echo e(\App\ORM\User::ACTIVE); ?>">Activo</option>
                            <option <?php echo e(( $model->state  == \App\ORM\User::INACTIVE ? 'selected' : '' )); ?> value="<?php echo e(\App\ORM\User::INACTIVE); ?>">Inactivo</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12  col-sm-6">
                    <div class="form-group">
                        <label >Ubicaci&oacute;n</label>
                        <select data-live-search="true" name="location_id" class="selectpicker form-control" id="">
                            <option value="">[Seleccione]</option>
                            <?php echo $__env->make('util.nested-tree-options',['listModels'=>$locations, 'level'=>'', 'selected'=>$model->location_id ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6">
                    <div class="form-group">
                        <label >Rol</label>
                        <select name="role_id" id="role_id" class="required form-control" >
                            <option value="">Selecciona</option>
                            <option <?php echo e(( $model->role_id  == \App\ORM\User::ROLE_ADMIN ? 'selected' : '' )); ?> value="<?php echo e(\App\ORM\User::ROLE_ADMIN); ?>">Administrador</option>
                            <option <?php echo e(( $model->role_id  == \App\ORM\User::ROLE_ENG ? 'selected' : '' )); ?> value="<?php echo e(\App\ORM\User::ROLE_ENG); ?>">Ingeniero</option>
                            <option <?php echo e(( $model->role_id  == \App\ORM\User::ROLE_SUPER ? 'selected' : '' )); ?> value="<?php echo e(\App\ORM\User::ROLE_SUPER); ?>">Supervisor</option>
                            <option <?php echo e(( $model->role_id  == \App\ORM\User::ROLE_CLIENT ? 'selected' : '' )); ?> value="<?php echo e(\App\ORM\User::ROLE_CLIENT); ?>">Cliente</option>
                            <option <?php echo e(( $model->role_id  == \App\ORM\User::ROLE_MANAGER ? 'selected' : '' )); ?> value="<?php echo e(\App\ORM\User::ROLE_MANAGER); ?>">Gerente</option>
                        </select>
                    </div>
                </div> 
            </div>
            <div class="row">                
                <div id="wrapt-clients" class="col-xs-12 col-sm-6" style="display: none">
                    <div class="form-group">
                        <label >Clientes</label>
                        <select name="client_id" data-live-search="true" class="required form-control selectpicker" >
                            <option value="0">Selecciona</option>
                            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e(( $client->getKey()  == $model->client_id ? 'selected' : '' )); ?> value="<?php echo e($client->getKey()); ?>"><?php echo e($client->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>
        </fieldset>
        <fieldset>
            <legend class="">Datos personales</legend>
            <div class="row">
                <div class="col-xs-12 col-sm-6">
                    <div class="form-group">
                        <label >Tipo de identificaci&oacute;n</label>
                        <select name="ide_type" class="required form-control" >
                            <option value="">Selecciona</option>
                            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php echo e(($type->getKey() == $model->ide_type ? 'selected' : '' )); ?> value="<?php echo e($type->getKey()); ?>"><?php echo e($type->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6">
                    <div class="form-group">
                        <label >N&uacute;mero de identificaci&oacute;n</label>
                        <input type="text" name="ide" class="required form-control" value="<?php echo e($model->ide); ?>" placeholder="">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 col-sm-6">
                    <div class="form-group">
                        <label >Tel&eacute;fono fijo</label>
                        <input type="text" name="phone" class="form-control" value="<?php echo e($model->phone); ?>" >
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6">
                    <div class="form-group">
                        <label >Tel&eacute;fono de celular</label>
                        <input type="text" name="cell" class="form-control" value="<?php echo e($model->cell); ?>" placeholder="">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 col-sm-6">
                    <div class="form-group">
                        <label >Direcci&oacute;n</label>
                        <input type="text" name="address" class="form-control" value="<?php echo e($model->address); ?>" placeholder="">
                    </div>
                </div>
            </div>            
        </fieldset>
        <fieldset>
            <legend>Contacto de empresa</legend>
            <div class="row">
                <div class="col-xs-12 col-sm-6">
                    <div class="form-group">
                        <label >Tel&eacute;fono fijo de empresa</label>
                        <input type="text" name="job_phone" class="form-control" value="<?php echo e($model->job_phone); ?>" placeholder="">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6">
                    <div class="form-group">
                        <label >Tel&eacute;fono celular de empresa</label>
                        <input type="text" name="job_cell" class="form-control" value="<?php echo e($model->job_cell); ?>" placeholder="">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 col-sm-6">
                    <div class="form-group">
                        <label >Direcci&oacute;n de empresa</label>
                        <input type="text" name="job_address" class="form-control" value="<?php echo e($model->job_address); ?>" placeholder="">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12">
                    <div alert ></div>
                </div>
            </div>
        </fieldset>
    </div>
    <div class="modal-footer">
        <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
        <button type="submit" class="btn btn-primary">Guardar</button>
    </div>
</form>