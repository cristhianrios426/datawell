<?php 
return [
	'Administrador',
	'Ingeniero',
	'Supervisor',
	'Cliente',
	'Gerente'
];