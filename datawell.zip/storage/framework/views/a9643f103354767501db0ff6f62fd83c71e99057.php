<div class="panel panel-default">
    <div class="panel-heading">
        <h5><?php echo e($model->type->name); ?></h5>
    </div>
    <div class="panel-body">
        <ul class="list-group">
          <li class="list-group-item"><strong>Estado:</strong> 
            <?php echo e($model->textState()); ?>               
          </li>
          <li class="list-group-item"><strong>Fecha de terminaci&oacute;n</strong> <?php echo e($model->ended_at->format('Y-m-d')); ?> </li>
          <li class="list-group-item"><strong>Pozo:</strong> <?php echo e(isset($model->well->name) ? $model->well->name : ''); ?> </li>
          <li class="list-group-item"><strong>Tipo de servicio :</strong> <?php echo e($model->type ? $model->type->name : ''); ?> </li>
          <li class="list-group-item"><strong>Tipo de secci&oacute;n:</strong> <?php echo e($model->section ? $model->section->name : ''); ?> </li>
          <li class="list-group-item"><strong>Decripci&oacute;n:</strong>  <?php echo e($model->description); ?> </li>
        </ul>
    </div>
    <div class="panel-footer text-right">                        
        <div class="btn-group">
          <button class="btn btn-primary">Acciones</button>
          <button data-toggle="dropdown" class="btn btn-primary dropdown-toggle"><span class="caret"></span></button>
          <ul class="dropdown-menu">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $model)): ?><li><a href="<?php echo e(route('service.edit', ['id'=>$model->id])); ?>"  >Editar</a></li><?php endif; ?>
            <li><a href="<?php echo e(route('service.show', ['id'=>$model->id])); ?>"  >Ver detalles</a></li>
            <li><a href="" data-href="<?php echo e(route('service.attachments', ['id'=>$model->id])); ?>" data-toggle="modal" data-target="#attachments-modal" >Ver archivos</a></li>
          </ul>
        </div>
    </div>
</div>