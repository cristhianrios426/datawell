<div class="row">
    <div class="col-xs-12">
        <div class="form-group">
            <label >Nombre  <strong class="require-mark">*</strong></label>
            <input type="text" name="name" class="form-control required" value="<?php echo e($model->name); ?>" >
        </div>
    </div>
</div>
<div class="row">
    <div class="col-xs-12 col-sm-6">
        <div class="form-group">
            <label >Coordenada en X  <strong class="require-mark">*</strong></label>
            <input type="text" name="x" class="number form-control required" value="<?php echo e($model->x); ?>" >
        </div>
    </div>
    <div class="col-xs-12 col-sm-6">
        <div class="form-group">
            <label >Coordenada en Y  <strong class="require-mark">*</strong></label>
            <input type="text" name="y" class="number form-control required" value="<?php echo e($model->y); ?>" >
        </div>
    </div>
</div>
<div class="row">
    <div class="col-xs-12 col-sm-6">
        <div class="form-group">
            <label >Coordenada en Z</label>
            <input type="text" name="z" class="number form-control required" value="<?php echo e($model->z); ?>" >
        </div>
    </div>
    <div class="col-xs-12 col-sm-6">
        <div class="form-group">
            <label >Sistema de coordenadas</label>
            <select name="ref_cor_sis_id" id="" class="form-control required">
                <option value="">Selecciona</option>
                <?php $__currentLoopData = $coorSystems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option <?php echo e(($model->ref_cor_sis_id == $sys->getKey() ? 'selected' : '' )); ?> value="<?php echo e($sys->getKey()); ?>"><?php echo e($sys->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-sm-6 col-xs-12">
         <div class="form-group">
            <label >Latitud</label>
            <input type="text" name="lat" class="form-control" value="<?php echo e($model->lat); ?>">   
        </div>
    </div>
    <div class="col-sm-6 col-xs-12">
        <div class="form-group">
            <label >Longitud</label>
            <input type="text" name="long" class="form-control" value="<?php echo e($model->long); ?>">   
        </div>
    </div>
</div>
<div class="row">
    <div class="col-xs-12 col-sm-6">
        <div class="form-group">
            <label >Profundidad TVD (ft)</label>
            <input type="number" name="profundidad_tvd" class="form-control" value="<?php echo e($model->z); ?>" >
        </div>
    </div>
    <div class="col-xs-12 col-sm-6">
        <div class="form-group">
            <label >Profundidad MD (ft)</label>
            <input type="number" name="profundidad_md" class="form-control" value="<?php echo e($model->z); ?>" >
        </div>
    </div>
</div>
<div class="row">
    <div class="col-xs-12 col-sm-6">
        <div class="form-group">
            <label >Well kb elev (ft)</label>
            <input type="number" name="well_kb_elev" class="form-control" value="<?php echo e($model->z); ?>" >
        </div>
    </div>
    <div class="col-xs-12 col-sm-6">
        <div class="form-group">
            <label >Rotaty elev (ft)</label>
            <input type="number" name="rotaty_elev" class="form-control" value="<?php echo e($model->z); ?>" >
        </div>
    </div>
</div>
<div class="row">
    <div class="col-xs-12">
        <div class="form-group">
            <label >Ubicaci&oacute;n  <strong class="require-mark">*</strong></label>
            <select selectpicker data-live-search="true" location-ref="loc" name="location_id" id="" class="required form-control">
                <?php echo $__env->make('util.nested-tree-options', ['listModels'=>$locations, 'level'=>'', 'selected'=>$model->location_id], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </select>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-xs-12 col-sm-6">
        <div class="form-group">
            <label >Cuenca  <strong class="require-mark">*</strong></label>
            <select location-list="cuenca" location-dep-ref name="cuenca_id" id="" class="required form-control">
                <option value="">Selecciona</option>
                <?php $__currentLoopData = $cuencas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuenca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option  <?php echo e(($model->cuenca_id == $cuenca->getKey() ? 'selected' : '' )); ?> value="<?php echo e($cuenca->getKey()); ?>"><?php echo e($cuenca->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <div class="col-xs-12 col-sm-6">
        <div class="form-group">
            <label >Campo  <strong class="require-mark">*</strong></label>
            <select location-list="camp" location-dep-ref name="camp_id" id="" class="required form-control">
                <option value="">Selecciona</option>
                <?php $__currentLoopData = $camps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $camp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option <?php echo e(($model->camp_id == $camp->getKey() ? 'selected' : '' )); ?> value="<?php echo e($camp->getKey()); ?>"><?php echo e($camp->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-xs-12 col-sm-6">
        <div class="form-group">
            <label >Regi&oacute;n  <strong class="require-mark">*</strong></label>
            <select location-list="area"  location-dep-ref name="area_id" id="" class="required form-control">
                <option value="">Selecciona</option>
                <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option  <?php echo e(($model->area_id == $area->getKey() ? 'selected' : '' )); ?> value="<?php echo e($area->getKey()); ?>"><?php echo e($area->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <div class="col-xs-12 col-sm-6">
        <div class="form-group">
            <label >Bloque  <strong class="require-mark">*</strong></label>
            <select location-list="block" location-dep-ref name="block_id" id="" class="required form-control">
                <option value="">Selecciona</option>
                <?php $__currentLoopData = $blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php echo e(($model->block_id == $block->getKey() ? 'selected' : '' )); ?> value="<?php echo e($block->getKey()); ?>"><?php echo e($block->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-xs-12 col-sm-6">
        <div class="form-group">
            <label >Tipo de pozo  <strong class="require-mark">*</strong></label>
            <select name="well_type_id" id="" class="required form-control">
                <option value="">Selecciona</option>
                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option <?php echo e(($model->well_type_id == $type->getKey() ? 'selected' : '' )); ?> value="<?php echo e($type->getKey()); ?>"><?php echo e($type->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <div class="col-xs-12 col-sm-6">
        <div class="form-group">
            <label >Desviación  <strong class="require-mark">*</strong></label>
            <select name="deviation_id" id="" class="required form-control">
                <option value="">Selecciona</option>
                <?php $__currentLoopData = $deviations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deviation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php echo e(($model->deviation_id == $deviation->getKey() ? 'selected' : '' )); ?> value="<?php echo e($deviation->getKey()); ?>"><?php echo e($deviation->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-sm-6 col-xs-12">
         <div class="form-group">
            <label >Operador  <strong class="require-mark">*</strong></label>
            <select name="operator_id" id="" class="required form-control">
                <option value="">Selecciona</option>
                <?php $__currentLoopData = $operators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php echo e(($model->operator_id == $operator->getKey() ? 'selected' : '' )); ?> value="<?php echo e($operator->getKey()); ?>"><?php echo e($operator->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <div class="col-sm-6 col-xs-12">
        <div class="form-group">
            <label >Fecha de perforaci&oacute;n <strong class="require-mark">*</strong></label>
            <input type="text" name="drilled_at" class="required form-control" value="<?php echo e($model->drilled_at); ?>">   
        </div>
    </div>
</div>