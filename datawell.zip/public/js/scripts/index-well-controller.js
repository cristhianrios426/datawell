(function(window, $){
	$('.selectpicker').selectpicker();
})(window, jQuery);