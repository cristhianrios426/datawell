<?php $__env->startSection('head'); ?>
	<meta name="entity" content="<?php echo e($entityName); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<?php echo $__env->make('util.breadcrums.settings',['active'=>ucfirst($entitiesLabel)], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="row">
		<div class="col-xs-12">
			<div class="panel panel-default">
				<div class="panel-heading">
					<div class="continer-fluid">
						<div class="row">
							<div class="col-xs-12">
								<div class="pull-left">
									<h4><?php echo e(ucfirst($entitiesLabel)); ?></h4>
								</div>
								<div class="pull-right">
									<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', $classname)): ?><button data-create data-toggle="modal" data-target="#modal-model" href="" class="btn btn-success">
										<i class="fa fa-plus"  aria-hidden="true"></i> Crear  <?php echo e($entityLabel); ?>

									</button><?php endif; ?>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="panel-body">
					<div class="fluid-container">						
						<div class="row">
							<div class="col-xs-12">
								<div class="just-padding">
									<div class="list-group list-group-root well">
										<?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php echo $__env->make('locations.list-item', ['model'=>$model], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</div>
								</div>
							</div>
						</div>
					</div>					
				</div>
			</div>

			<div class="modal fade " tabindex="-1" role="dialog" id="modal-model" aria-hidden="true" >
				<div class="modal-dialog ">
					<div class="modal-content" id="modal-content">
						
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
	<link rel="stylesheet" href="<?php echo e(asset('vendors/bootstrap-select/dist/css/bootstrap-select.min.css')); ?>">
    <script src="<?php echo e(asset('vendors/bootstrap-select/dist/js/bootstrap-select.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/bootstrap-select/dist/js/i18n/defaults-'.\Config::get('app.locale').'.js')); ?>"></script>
    <script src="<?php echo e(asset('js/scripts/entity.js')); ?>"></script>
    <script src="<?php echo e(asset('js/scripts/location-controller.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>