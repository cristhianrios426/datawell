<?php if($model->state == \App\ORM\Service::STATE_REVIEWING): ?>
    <div class="alert alert-warning">
    	<h4>Este pozo está siendo revisado por un supervisor</h4>
    </div>
<?php endif; ?>
<?php if($model->state == \App\ORM\Service::STATE_APPROVING): ?>
	<div class="alert alert-warning">
    	<h4>Este pozo fue enviado al ingeniero  para su revisi&oacute;n</h4>
    </div>
<?php endif; ?>
