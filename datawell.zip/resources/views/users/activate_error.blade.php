<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Gentelella Alela! | </title>
    <!-- Bootstrap -->
    <link href=" {{{ asset('vendors/bootstrap/dist/css/bootstrap.min.css') }}}" rel="stylesheet">
    <!-- Font Awesome -->
    <link href=" {{{ asset('vendors/font-awesome/css/font-awesome.min.css') }}}" rel="stylesheet">
    <!-- NProgress -->
    <link href=" {{{ asset('vendors/nprogress/nprogress.css') }}}" rel="stylesheet">
    <!-- Animate.css -->
    <link href=" {{{ asset('vendors/animate.css/animate.min.css') }}}" rel="stylesheet">
    <!-- Custom Theme Style -->
    <link href="../build/css/custom.css" rel="stylesheet">
    <style>
    .container{
    }
    </style>
  </head>
  <body class="login">
  
      
    <section  class="container" >
   
      <div class="row">
        <div class="col-xs-12"><h1>Error URL de activaci&oacute;n</h1></div>
      </div>
      <div class="row">
        <div class="col-xs-12">
          <div class="alert alert-warning">
            El token de activaci&oacute;n est&aacute; errado, ha expirado o tu usuario est&aacute; inactivo
          </div>
        </div>
      </div>
    </section>
      
 
</body>
</html>