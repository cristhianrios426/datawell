<div class="row">
    <div class="col-xs-12 col-sm-6">
        <div class="form-group">
            <label >Cliente<strong class="require-mark">*</strong></label>
            <select  name="client_id"  class="require form-control required">
                <option value="">Selecciona</option>
                <?php $__currentLoopData = \App\ORM\Client::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option <?php echo e($model->client && $model->client_id == $client->getKey() ? 'selected' : ''); ?> value="<?php echo e($client->getKey()); ?>"><?php echo e($client->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <div class="col-xs-12 col-sm-6">
        <div class="form-group">
            <label >Unidad de negocios<strong class="require-mark">*</strong></label>
            <select business-unit name="businessUnit"  class="selectpicker require form-control required">
                <option value="">Selecciona</option>
                <?php if($model->exists && $model->type  && $model->type->businessUnit): ?>
                    <?php $__currentLoopData = \App\ORM\BusinessUnit::orderBy('name', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option <?php echo e(($model->type->businessUnit->getKey() == $bs->getKey() ? 'selected' : '' )); ?> value="<?php echo e($bs->getKey()); ?>"><?php echo e($bs->name); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <?php $__currentLoopData = \App\ORM\BusinessUnit::orderBy('name', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($bs->getKey()); ?>"><?php echo e($bs->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </select>
        </div>
    </div>
</div>                                    
<div class="row">
    <div class="col-xs-12 col-sm-6">
        <div class="form-group">
            <label >Tipo de servicio <strong class="require-mark">*</strong></label>
            <select service-type location-dep-ref name="service_type_id"  class="require form-control required">
                <option value="">Selecciona</option>
                <?php $__currentLoopData = $serviceTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serviceType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option business-unit="<?php echo e($serviceType->businessUnit->getKey()); ?>" <?php echo e(($model->service_type_id == $serviceType->getKey() ? 'selected' : '' )); ?> value="<?php echo e($serviceType->getKey()); ?>"><?php echo e($serviceType->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <div class="col-xs-12 col-sm-6">
        <div class="form-group">
            <label >Pozo <strong class="require-mark">*</strong> </label>
            <select name="well_id" id="select-well"  data-live-search="true" class="selectpicker require form-control required">
                <option value="">Selecciona</option>
                <?php $__currentLoopData = $wells; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $well): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($model->exists): ?>
                    <option <?php echo e(($model->well_id == $well->getKey() ? 'selected' : '' )); ?> value="<?php echo e($well->getKey()); ?>"><?php echo e($well->name); ?></option>
                  <?php else: ?>
                    <option <?php echo e(($prewell == $well->getKey() ? 'selected' : '' )); ?> value="<?php echo e($well->getKey()); ?>"><?php echo e($well->name); ?></option>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-xs-12 col-sm-6">
        <div class="form-group">
            <label >Tipo de secci&oacute;n <strong class="require-mark">*</strong> </label>
            <select name="section_id"  data-live-search="true" class="selectpicker require form-control required">
                <option value="">Selecciona</option>
                <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option <?php echo e(($model->section_id == $section->getKey() ? 'selected' : '' )); ?> value="<?php echo e($section->getKey()); ?>"><?php echo e($section->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <div class="col-xs-12 col-sm-6">
        <div class="form-group">
            <label >Fecha de terminaci&oacute;n <strong class="require-mark">*</strong> </label>
            <input type="text" name="ended_at" class="form-control required date"  value="<?php echo e($model->ended_at); ?>" >
        </div>
    </div>
</div>
<div class="row">
    <div class="col-xs-12">
         <div class="form-group">
            <label >Descripci&oacute;n</label>
            <textarea name="description" class="form-control" id="" ><?php echo e($model->description); ?></textarea>
        </div>
    </div>
</div>