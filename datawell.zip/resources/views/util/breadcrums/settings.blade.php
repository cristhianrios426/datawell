<div class="row">
	<div class="col-xs-12">
		<ol class="breadcrumb">
		  <li><a href="{{{ url('/') }}}">Inicio</a></li>
		  <li>Ajustes</li>
		  <li class="active">{{{ $active }}}</li>
		</ol>
	</div>
</div>