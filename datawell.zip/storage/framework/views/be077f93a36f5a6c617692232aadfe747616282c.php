<div class="row">
	<div class="col-xs-12">
		<ol class="breadcrumb">
		  <li><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
		  <li>Ajustes</li>
		  <li class="active"><?php echo e($active); ?></li>
		</ol>
	</div>
</div>