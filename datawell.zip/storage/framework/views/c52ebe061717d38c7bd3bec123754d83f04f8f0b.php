<?php $__env->startSection('head'); ?>
  <meta name="entity" content="<?php echo e($entityName); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
     <div class="row">
        <div class="col-xs-12">
            <?php echo $__env->make('wells.state-message', ['model'=>$model], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 ><?php echo e($model->name); ?></h4>
                </div>
                <div class="panel-body">
                    <div class="fluid-container">
                        <div class="row">
                            <div class="col-xs-12">
                                <?php echo $__env->make('wells.inner-show', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </div>
                            <div class="col-xs-12">
                                <div class="fluid-container">
                                    <div class="row">
                                        <div class="col-xs-12">
                                            <h4>Archivos adjuntos</h4>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <?php $__currentLoopData = $model->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-xs-4">
                                                <div class="well">
                                                    <div>
                                                         <span class="label label-<?php echo e($attachment->approved ? 'success' : 'warning'); ?>"><?php echo e($attachment->approved ? 'Aprobado' : 'No aprobado'); ?></span>
                                                      </div>
                                                    <a href="<?php echo e($model->routeToAttachment($attachment->getKey())); ?>" data-url target="_blank">
                                                        <div data-name=""> <?php echo e($attachment->name); ?></div>
                                                    </a>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
                <div class="panel-footer text-right">                        
                    <div class="btn-group">
                      <button class="btn btn-primary">Acciones</button>
                      <button data-toggle="dropdown" class="btn btn-primary dropdown-toggle"><span class="caret"></span></button>
                      <ul class="dropdown-menu">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $model)): ?><li><a href="<?php echo e(route($entityName.'.edit', ['id'=>$model->id])); ?>"  >Editar</a></li><?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $model)): ?><li><a href="<?php echo e(route('service.create',['id_well'=>$model->getKey()])); ?>"  >A&ntilde;adir servicio</a></li><?php endif; ?>
                        <li><a href="<?php echo e(route($entityName.'.index')); ?>"  >Ver listado</a></li>
                      </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xs12">
            <h4>Sevicios</h4>
        </div>
    </div>    
    <div class="row">
         <?php $__currentLoopData = $model->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xs-12 col-sm-6">
                <?php echo $__env->make('services.thumb',['model'=>$service], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<div class="modal fade" id="attachments-modal" tabindex="-1" role="dialog" >
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"></h4>
            </div>
            <div class="modal-body">
                <p>One fine body&hellip;</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save changes</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>