<div>
	@yield('body')
</div>