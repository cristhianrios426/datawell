<?php $__env->startSection('head'); ?>
  <meta name="entity" content="<?php echo e($entityName); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <form action="<?php echo e(( !$model->exists  ? route('well.store') : route('well.update',['id'=>$model->getKey()]))); ?>" method="<?php echo e(( !$model->exists  ? 'POST' : 'PUT' )); ?>">
        <div class="row">
            <div class="col-xs-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <?php if( !$model->exists ): ?>
                            <h4 class="modal-title">Nuevo <?php echo e($entityLabel); ?></h4>
                        <?php else: ?>
                            <h4 class="modal-title">Editando <?php echo e($entityLabel); ?> <?php echo e($model->name); ?></h4>
                        <?php endif; ?>
                    </div>
                    <div class="panel-body">
                        <div class="fluid-container">
                            <div class="row">
                                <div class="col-xs-12 col-sm-8">
                                    <div class="row">
                                        <div class="col-xs-12">
                                            <div class="form-group">
                                                <label >Nombre  <strong class="require-mark">*</strong></label>
                                                <input type="text" name="name" class="require form-control required" value="<?php echo e($model->name); ?>" >
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label >Coordenada en X  <strong class="require-mark">*</strong></label>
                                                <input type="text" name="x" class="require form-control required" value="<?php echo e($model->x); ?>" >
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label >Coordenada en Y  <strong class="require-mark">*</strong></label>
                                                <input type="text" name="y" class="require form-control required" value="<?php echo e($model->y); ?>" >
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label >Coordenada en Z</label>
                                                <input type="text" name="z" class="require form-control required" value="<?php echo e($model->z); ?>" >
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label >Sistema de coordenadas</label>
                                                <select name="id_ref_cor_sis" id="" class="require form-control required">
                                                    <option value="">Selecciona</option>
                                                    <?php $__currentLoopData = $coorSystems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php echo e(($model->id_ref_cor_sis == $sys->getKey() ? 'selected' : '' )); ?> value="<?php echo e($sys->getKey()); ?>"><?php echo e($sys->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6 col-xs-12">
                                             <div class="form-group">
                                                <label >Latitud</label>
                                                <input type="text" name="lat" class="form-control" value="<?php echo e($model->lat); ?>">   
                                            </div>
                                        </div>
                                        <div class="col-sm-6 col-xs-12">
                                            <div class="form-group">
                                                <label >Longitud</label>
                                                <input type="text" name="long" class="form-control" value="<?php echo e($model->long); ?>">   
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label >Profundidad TVD (ft)</label>
                                                <input type="number" name="profundidad_tvd" class="form-control" value="<?php echo e($model->z); ?>" >
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label >Profundidad MD (ft)</label>
                                                <input type="number" name="profundidad_md" class="form-control" value="<?php echo e($model->z); ?>" >
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label >Well kb elev (ft)</label>
                                                <input type="number" name="well_kb_elev" class="form-control" value="<?php echo e($model->z); ?>" >
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label >Rotaty elev (ft)</label>
                                                <input type="number" name="rotaty_elev" class="form-control" value="<?php echo e($model->z); ?>" >
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label >Cuenca  <strong class="require-mark">*</strong></label>
                                                <select name="id_cuenca" id="" class="require form-control">
                                                    <option value="">Selecciona</option>
                                                    <?php $__currentLoopData = $cuencas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuenca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option  <?php echo e(($model->id_cuenca == $cuenca->getKey() ? 'selected' : '' )); ?> value="<?php echo e($cuenca->getKey()); ?>"><?php echo e($cuenca->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label >Campo  <strong class="require-mark">*</strong></label>
                                                <select name="id_camp" id="" class="require form-control">
                                                    <option value="">Selecciona</option>
                                                    <?php $__currentLoopData = $camps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $camp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php echo e(($model->id_camp == $camp->getKey() ? 'selected' : '' )); ?> value="<?php echo e($camp->getKey()); ?>"><?php echo e($camp->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label >Regi&oacute;n  <strong class="require-mark">*</strong></label>
                                                <select name="id_area" id="" class="require form-control">
                                                    <option value="">Selecciona</option>
                                                    <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php echo e(($model->id_area == $area->getKey() ? 'selected' : '' )); ?> value="<?php echo e($area->getKey()); ?>"><?php echo e($area->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label >Bloque  <strong class="require-mark">*</strong></label>
                                                <select name="id_block" id="" class="require form-control">
                                                    <option value="">Selecciona</option>
                                                    <?php $__currentLoopData = $blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option <?php echo e(($model->id_block == $block->getKey() ? 'selected' : '' )); ?> value="<?php echo e($block->getKey()); ?>"><?php echo e($block->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label >Tipo de pozo  <strong class="require-mark">*</strong></label>
                                                <select name="id_well_type" id="" class="require form-control">
                                                    <option value="">Selecciona</option>
                                                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php echo e(($model->id_well_type == $type->getKey() ? 'selected' : '' )); ?> value="<?php echo e($type->getKey()); ?>"><?php echo e($type->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label >Desviación  <strong class="require-mark">*</strong></label>
                                                <select name="id_deviation" id="" class="require form-control">
                                                    <option value="">Selecciona</option>
                                                    <?php $__currentLoopData = $desviations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desviation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option <?php echo e(($model->id_deviation == $desviation->getKey() ? 'selected' : '' )); ?> value="<?php echo e($desviation->getKey()); ?>"><?php echo e($desviation->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-sm-6 col-xs-12">
                                             <div class="form-group">
                                                <label >Operador  <strong class="require-mark">*</strong></label>
                                                <select name="id_operator" id="" class="require form-control">
                                                    <option value="">Selecciona</option>
                                                    <?php $__currentLoopData = $operators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option <?php echo e(($model->id_operator == $operator->getKey() ? 'selected' : '' )); ?> value="<?php echo e($operator->getKey()); ?>"><?php echo e($operator->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-sm-6 col-xs-12">
                                            <div class="form-group">
                                                <label >Fecha de perforaci&oacute;n <strong class="require-mark">*</strong></label>
                                                <input type="text" name="drilled_at" class="require form-control" value="<?php echo e($model->drilled_at); ?>">   
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xs-12 col-sm-4">
                                    <div class="row">
                                        <div class="col-xs-12">
                                            <h4>Archivos adjuntos</h4>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xs-12">
                                            <div id="list-files">
                                                <?php $__currentLoopData = $model->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                     <div class="well " data-old-attachment >
                                                        <a href="<?php echo e($model->routeToAttachment($attachment->id)); ?>" data-url target="_blank">
                                                            <div data-name=""><?php echo e($attachment->name); ?></div>
                                                        </a>
                                                        <input type="hidden" data-servername name="old_attachments[<?php echo e($key); ?>][id]" value="<?php echo e($attachment->getKey()); ?>">
                                                        <input data-removed type="hidden" data-servername name="old_attachments[<?php echo e($key); ?>][deleted]" value="0">
                                                        <button data-remove class="btn btn-danger btn-xs">eliminar</button>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                            <div class="btn btn-success relative" data-uploader="" >
                                                <span><i class="fa fa-cloud-upload" aria-hidden="true"></i> &nbsp;Adjuntar archivo</span>
                                                <input type="file" name="file" class="hidden-action">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-12">
                                   <small>Los campos marcado son <strong class="require-mark">*</strong> son obligatorios</small>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-12">
                                    <div alert=""></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="panel-footer text-right">
                        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-warning">
                            Cancelar
                        </a>
                        <button type="submit" class="btn btn-primary">
                            Guardar
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
<div style="display: none" id="template-file">
    <div class="well">
        <a href="#" data-url target="_blank">
            <div data-name=""></div>
        </a>
        <div data-progress=""></div>
        <input type="hidden" data-servername name="attachments[{id}][file]">
        <input type="hidden" data-clientname name="attachments[{id}][name]">
        <button data-remove="" class="btn btn-danger btn-xs">eliminar</button>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <script src="<?php echo e(asset('vendors/fileuploader/compiled.js')); ?>"></script>
    <script src="<?php echo e(asset('js/scripts/jquery.datawelluploader.js')); ?>"></script>
    <script src="<?php echo e(asset('js/scripts/entity.js')); ?>"></script>  
    <script src="<?php echo e(asset('js/scripts/jquery.sendajax.js?t='.time())); ?>"></script>  
    <script src="<?php echo e(asset('js/scripts/well-controller.js?t='.time())); ?>"></script>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>