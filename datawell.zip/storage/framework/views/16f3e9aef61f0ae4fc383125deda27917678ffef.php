<?php $__env->startSection('content'); ?>
<div class="container">
	<?php echo $__env->make('util.breadcrums.settings',['active'=>ucfirst($entitiesLabel)], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="row">
		<div class="col-xs-12">
			<div class="panel panel-default">
				<div class="panel-heading">
					<div class="continer-fluid">
						<div class="row">
							<div class="col-xs-12">
								<div class="pull-left">
									<h4><?php echo e(ucfirst($entitiesLabel)); ?></h4>
								</div>
								<div class="pull-right">
									<button data-create data-toggle="modal" data-target="#modal-model" href="" class="btn btn-success">
										<i class="fa fa-plus"  aria-hidden="true"></i> Crear <?php echo e($entityLabel); ?>

									</button>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="panel-body">
					<div class="fluid-container">
						<div class="row">
							<div class="col-md-offset-6 col-md-6 col-xs-12">
								<form action="<?php echo e(route('user.index')); ?>">
									<div class="input-group">
							       		<input type="text" name="term" class="form-control" value="<?php echo e((isset($query['term']) ? $query['term'] : '' )); ?>">
							        	<span class="input-group-btn">
							              	<button type="submit" class="btn btn-primary">Buscar</button>
							          	</span>
							      	</div>
							      	<br>
								</form>
							</div>
						</div>
					</div>
					<?php if($models->count() > 0): ?>

					<table class="data-table table table-striped table-bordered dt-responsive nowrap">
						<thead>
							<tr>
								<th>ID</th>
								<th><a href="<?php echo e($sortLinks['name']['url']); ?>">Nombre <i class="fa fa-<?php echo e($sortLinks['name']['type']); ?>"></i></a></th>
								<th><a href="<?php echo e($sortLinks['email']['url']); ?>">Email <i class="fa fa-<?php echo e($sortLinks['email']['type']); ?>"></i></a></th>
								<th><a href="<?php echo e($sortLinks['ide']['url']); ?>">No. de identificaci&oacute;n <i class="fa fa-<?php echo e($sortLinks['ide']['type']); ?>"></i></a></th>
								<th><a href="">Rol</a></th>
								<th>Acciones</th>
							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($model->id); ?></td>
									<td><?php echo e($model->name); ?></td>
									<td><?php echo e($model->email); ?></td>
									<td><?php echo e($model->ide); ?></td>
									<td><?php echo e($model->roleName()); ?></td>
									<td>
										<div class="btn-group">
										  <button class="btn btn-primary">Acciones</button>
										  <button data-toggle="dropdown" class="btn btn-primary dropdown-toggle"><span class="caret"></span></button>
										  <ul class="dropdown-menu">
											<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $model)): ?> <li><a href="#" data-toggle="modal" data-target="#modal-model" data-edit="<?php echo e($model->getKey()); ?>">Editar</a></li> <?php endif; ?>
											<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $model)): ?> <li><a href="#" data-toggle="modal" data-target="#modal-model" data-remove="<?php echo e($model->getKey()); ?>">Eliminar</a></li> <?php endif; ?>
								
											<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', $model)): ?> <li><a href="#" data-toggle="modal" data-target="#modal-model" data-show="<?php echo e($model->getKey()); ?>">Detalles</a></li> <?php endif; ?>
								
										  </ul>
										</div>
									</td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
					<?php else: ?>
						<div class="alert alert-primary">
							<h2> No se han encontrado resultados </h2>
						</div>
					<?php endif; ?>
					<div class="text-right">
						<div class="inline-block"><?php echo e($models->render()); ?></div> 	
					</div>
				</div>
			</div>

			<div class="modal fade " tabindex="-1" role="dialog" id="modal-model" aria-hidden="true" >
				<div class="modal-dialog ">
					<div class="modal-content" id="modal-content">
						
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>	
	<link rel="stylesheet" href="<?php echo e(asset('vendors/bootstrap-select/dist/css/bootstrap-select.min.css')); ?>">
    <script src="<?php echo e(asset('vendors/bootstrap-select/dist/js/bootstrap-select.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/bootstrap-select/dist/js/i18n/defaults-'.\Config::get('app.locale').'.js')); ?>"></script>
    <script src="<?php echo e(asset('js/scripts/entity.js')); ?>"></script>
    <script src="<?php echo e(asset('js/scripts/user-controller.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>